namespace ReadJournal.Library.Models;
public class DayActivity
{
    public DateTime Date { get; init; }
    public long Pages { get; init; }
    public long Minutes { get; init; }
    public double BarValue { get; init; }
    public string Label => $"{Date:MM-dd} · {Pages} 页 / {Minutes} 分钟";
}
